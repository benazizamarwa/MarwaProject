package dockerutil

type Feature string

const OCIImporter Feature = "OCI importer"
